#include "robot_control.h"
#include "adc.h"
#include "obstacle.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MOTOR_STOP 0
#define MOTOR_FORWARD 1
#define MOTOR_BACKWARD 2
#define HBRI_L1_HIGH()   (GPIOA->ODR |= BIT14)
#define HBRI_L1_LOW()    (GPIOA->ODR &= ~BIT14)

#define HBRI_L2_HIGH()   (GPIOA->ODR |= BIT15)
#define HBRI_L2_LOW()    (GPIOA->ODR &= ~BIT15)

#define HBRI_R1_HIGH()   (GPIOA->ODR |= BIT12)
#define HBRI_R1_LOW()    (GPIOA->ODR &= ~BIT12)

#define HBRI_R2_HIGH()   (GPIOA->ODR |= BIT13)
#define HBRI_R2_LOW()    (GPIOA->ODR &= ~BIT13)
#define INTERSECTION_THRESHOLD  3400
//(2/3.3)*4095

#define baud 3000 // baud rate of ir

// volatile uint8_t mode = 0;

volatile unsigned char pwm_left = 0;
volatile unsigned char pwm_right = 0;
volatile unsigned char pwm_counter = 0;
volatile unsigned char left_dir = MOTOR_STOP;
volatile unsigned char right_dir = MOTOR_STOP;
// 3 path 8 intersection 
static const PathAction path_table[3][8] =
{ //path 1,2,3
    { Go_forward, Go_left,    Go_left,    Go_forward, Go_right,   Go_left,    Go_right,   End_stop },
    { Go_left,    Go_right,   Go_left,    Go_right,   Go_forward, Go_forward, End_stop,   End_stop },
    { Go_right,   Go_forward, Go_right,   Go_left,    Go_right,   Go_left,    Go_forward, End_stop }
};
PathAction get_path_action(unsigned char path_number, unsigned char intersection_count)
{ //path table start from 0 (not1)
    /*if (path_number < 1 || path_number > 3 || intersection_count < 1 || intersection_count > 8)
        return End_stop;*/
   return path_table[path_number - 1][intersection_count - 1];
}

void PWM_Hardware_Init(void)
{
	// Set up output pins
	RCC->IOPENR |= BIT0; // peripheral clock enable for port A
   
    // PA15 -> HBRI_L1
    GPIOA->MODER = (GPIOA->MODER & ~(BIT28 | BIT29)) | BIT28;
    GPIOA->OTYPER &= ~BIT14;
    // PA14 -> HBRI_L2
    GPIOA->MODER = (GPIOA->MODER & ~(BIT30 | BIT31)) | BIT30;
    GPIOA->OTYPER &= ~BIT15;
    // PA13 -> HBRI_R1
    GPIOA->MODER = (GPIOA->MODER & ~(BIT24 | BIT25)) | BIT24;
    GPIOA->OTYPER &= ~BIT12;
    // PA8 -> HBRI_R2
    GPIOA->MODER = (GPIOA->MODER & ~(BIT26 | BIT27)) | BIT26;
    GPIOA->OTYPER &= ~BIT13;
    
    RCC->APB1ENR |= BIT17; //usart2 clock
    
    // PA3 for alternate fx 4 (usart2 rx)
    GPIOA->MODER = (GPIOA->MODER & ~(BIT6 | BIT7)) | BIT7;
    GPIOA->AFR[0] = (GPIOA->AFR[0] & ~0xF000) | 0x4000;
    
    USART2->BRR = F_CPU / baud;
    
    USART2->CR1 = BIT0 | BIT2 | BIT5;
    
    // PA2->potentiometer input
    GPIOA->MODER |= (BIT4 | BIT5);
    
	// Set up timer
    GPIOA->ODR &= ~(BIT8 | BIT11 | BIT12 | BIT13 | BIT14 | BIT15);//push down other pins
	RCC->APB1ENR |= BIT0;  // turn on clock for timer2 (UM: page 177)
	TIM2->ARR = F_CPU / 100000L - 1;
	NVIC->ISER[0] |= BIT15; // enable timer 2 interrupts in the NVIC
	TIM2->CR1 |= BIT4;      // Downcounting    
	TIM2->CR1 |= BIT7;      // ARPE enable    
	TIM2->DIER |= BIT0;     // enable update event (reload event) interrupt 
	TIM2->CR1 |= BIT0;      // enable counting    
	
	// trying to get a potentiometer input
	// RCC->IOPENR |= BIT1;  //periphreal clock enabled
	// GPIOB->MODER |= (BIT8 | BIT9);  // select analog mode for PA2 (pin8)
	
	NVIC->ISER[0] |= (1UL << 28); // usart is IRQ 28
	
	__enable_irq();
}

void TIM2_Handler(void)
{
    TIM2->SR &= ~BIT0; // clear update interrupt flag

    pwm_counter++;
    if (pwm_counter >= PWM_PERIOD_COUNT)
    {
        pwm_counter = 0;
    }
    //Left motor
    if (left_dir == MOTOR_FORWARD)
    {
        if (pwm_counter < pwm_left)
            HBRI_L1_HIGH();
        else
            HBRI_L1_LOW();
        HBRI_L2_LOW();
    }
    else if (left_dir == MOTOR_BACKWARD)
    {
        HBRI_L1_LOW();

        if (pwm_counter < pwm_left)
            HBRI_L2_HIGH();
        else
            HBRI_L2_LOW();
    }
    else
    {
        HBRI_L1_LOW();
        HBRI_L2_LOW();
    }

    //Right motor
    if (right_dir == MOTOR_FORWARD)
    {
        if (pwm_counter < pwm_right)
            HBRI_R1_HIGH();
        else
            HBRI_R1_LOW();
        HBRI_R2_LOW();
    }
    else if (right_dir == MOTOR_BACKWARD)
    {
        HBRI_R1_LOW();

        if (pwm_counter < pwm_right)
            HBRI_R2_HIGH();
        else
            HBRI_R2_LOW();
    }
    else
    {
        HBRI_R1_LOW();
        HBRI_R2_LOW();
    }
}

void USART2_Handler(void) {

	if (USART2->ISR & (BIT3 | BIT1 | BIT0)) {
		USART2->ICR |= (BIT3 | BIT1 | BIT0);
	}
	
	if (USART2->ISR & BIT5) {
		uint8_t data = (uint8_t)USART2->RDR;
		
		handle_instr(data);
	}
		
}

volatile int x;

void delay(int dly)
{
    while(dly--) x++;
}

void LED_Init(void)
{
    RCC->IOPENR |= BIT0; 
    GPIOA->MODER = (GPIOA->MODER & ~(BIT17 | BIT16)) | BIT16;
    GPIOA->MODER = (GPIOA->MODER & ~(BIT7 | BIT6)) | BIT6;
    GPIOA->ODR &= ~(BIT8 | BIT3);
}

void Turn_Left(void)
{
    GPIOA->ODR |= BIT8;
    GPIOA->ODR &= ~BIT3;
}

void Turn_Right(void)
{
    GPIOA->ODR |= BIT3;
    GPIOA->ODR &= ~BIT8;
}

void Lights_Off(void)
{
    GPIOA->ODR &= ~(BIT8 | BIT3);
}

void Hazard_Lights(void)
{
    GPIOA->ODR |= (BIT8 | BIT3);
    delay(500000);
    GPIOA->ODR &= ~(BIT8 | BIT3);
    delay(500000);
}
void motor_stop(void)
{
    left_dir = MOTOR_STOP;
    right_dir = MOTOR_STOP;

    pwm_left = 0;
    pwm_right = 0;

    HBRI_L1_LOW();
    HBRI_L2_LOW();
    HBRI_R1_LOW();
    HBRI_R2_LOW();
}

void motor_forward(unsigned char speed)
{
    left_dir = MOTOR_FORWARD;
    right_dir = MOTOR_FORWARD;

    pwm_left = speed;
    pwm_right = speed;
}

void motor_backward(unsigned char speed)
{
    left_dir = MOTOR_BACKWARD;
    right_dir = MOTOR_BACKWARD;

    pwm_left = speed;
    pwm_right = speed;
}

void motor_rotate_left(unsigned char speed)
{
    left_dir = MOTOR_BACKWARD;
    right_dir = MOTOR_FORWARD;

    pwm_left = speed;
    pwm_right = speed;
}

void motor_rotate_right(unsigned char speed)
{
    left_dir = MOTOR_FORWARD;
    right_dir = MOTOR_BACKWARD;

    pwm_left = speed;
    pwm_right = speed;
}

void motor_slight_change(unsigned char left_speed, unsigned char right_speed)
{
    left_dir = MOTOR_FORWARD;
    right_dir = MOTOR_FORWARD;

    pwm_left = left_speed;
    pwm_right = right_speed;
}

void execute_path_action(PathAction action)
{
	printf("execute start\r\n");
    switch (action)
    {
        case Go_forward:
        	Lights_Off();
        	printf("execute Forward\r\n");
        	motor_stop();
        	delayms(300);
            motor_forward(20); //speed not sure
            delayms(3000);
            motor_stop();
        	delayms(300);
            break;

        case Go_left:
        	Turn_Left();
        	printf("execute Left\r\n");
       		motor_stop();
        	delayms(300);
            motor_rotate_left(40);
            delayms(1300);
            motor_forward(20);
            delayms(1500);
            motor_stop();
        	delayms(300);
        	Lights_Off();
            break;

        case Go_right:
        	Turn_Right();
        	printf("execute right\r\n");
        	motor_stop();
        	delayms(300);
            motor_rotate_right(40);
            delayms(1300);
            motor_forward(20);
            delayms(1500);
            motor_stop();
        	delayms(300);
        	Lights_Off();
            break;

        case End_stop:
        	motor_stop();
        	delayms(2000);
        default:
        	Hazard_Lights();
            motor_stop();
            Lights_Off();
            break;
    }
    printf("execute end\r\n");
}

#define span 100
void move_forward_with_field_detection(void)
{
    unsigned int left_val, right_val;
    int error;
    left_val = adc_read_left();
    right_val = adc_read_right();
    error = (int)left_val - (int)right_val;
    
    if(error >= 300)//left big
    {
    	 motor_slight_change(10,20);
    }
    else if(error <= -300)
    {
    	motor_slight_change(20, 10);
    }else
    {
    	motor_forward(15);
    	
    }
    
    /*if(left_val >= 1000)
    {
    	 motor_slight_change(20,10);
    }
    else if(right_val >= 1000)
    {
    	motor_slight_change(10, 20);
    }else
    {
    	motor_forward(10);
    }*/
}
unsigned char intersection_detected(void)
{
    unsigned int inter_val;
    inter_val = adc_read_intersection();

    if (inter_val > INTERSECTION_THRESHOLD)
        return 1;
    else
        return 0;
}

void auto_mode_task(unsigned char path_number, volatile unsigned char *intersection_count)
{
    static unsigned char in_intersection = 0;
    
    if(Obstacle_IsBlocked())
    {
    	motor_stop();
    	Hazard_Lights();
    	return;
    }
    if (intersection_detected())
    {
        if (!in_intersection)
        {
            in_intersection = 1;
            (*intersection_count)++;
           
            execute_path_action(get_path_action(path_number, *intersection_count));
            delayms(500);
            return;
        }
    }
    else
    {
        in_intersection = 0;
    }
    move_forward_with_field_detection();
}

uint8_t get_resistance() {
	uint8_t pot_volt = readADC(ADC_CHSELR_CHSEL2);
	uint8_t r = (100*pot_volt)/(4097-pot_volt);
	return r;
} 

void handle_instr(uint8_t instr)
{
	uint8_t resist = get_resistance();
	if (current_mode == Manual_mode) {
	switch (instr) {
		case '1':
			path_number = 1;
			break;
		case '2':
			path_number = 2;
			break;
		case '3':
			path_number = 3;
			break;
		case 'S':
			motor_stop();
			//turning_timer = 0; 
			break;
		case 'M':
			current_mode = Auto_mode;
			intersection_count = 0;
			break;
		case 'R':
			motor_rotate_right(100 / resist);
			//turning_timer = 15;
			break;
		case 'L':
			motor_rotate_left(100 / resist);
			//turning_timer = 15;
			break;
		case 'O':
			motor_rotate_right(100 / resist);
			//turning_timer = 30;
			break;
		case 'F':
			motor_forward(100 / resist);
			//turning_timer = 0;
			break;
		case 'B':
			motor_backward(100 / resist);
			//turning_timer = 0;
			break;
		default:
			break;
		}
	} else { // robot is in auto mode
		switch (instr) {
			case 'M':
				motor_stop();
				current_mode = Manual_mode;
				break;
			default:
				break;
		}
	}
}


