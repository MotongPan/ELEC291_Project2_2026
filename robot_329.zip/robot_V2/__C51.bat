@echo off
::This file was created automatically by CrossIDE to compile with C51.
C:
cd "\Users\User\Documents\robot_V2\"
"C:\CrossIDE\Call51\Bin\c51.exe" --use-stdout  "C:\Users\User\Documents\robot_V2\test1.c"
if not exist hex2mif.exe goto done
if exist test1.ihx hex2mif test1.ihx
if exist test1.hex hex2mif test1.hex
:done
echo done
echo Crosside_Action Set_Hex_File C:\Users\User\Documents\robot_V2\test1.hex
