SHELL=cmd
CC=arm-none-eabi-gcc
AS=arm-none-eabi-as
LD=arm-none-eabi-ld
CCFLAGS=-mcpu=cortex-m0 -mthumb -g 

GCCPATH=$(subst \bin\arm-none-eabi-gcc.exe,\,$(shell where $(CC)))
LIBPATH1=$(subst \libgcc.a,,$(shell dir /s /b "$(GCCPATH)*libgcc.a" | find "v6-m"))
LIBPATH2=$(subst \libc_nano.a,,$(shell dir /s /b "$(GCCPATH)*libc_nano.a" | find "v6-m"))
LIBSPEC=-L"$(LIBPATH1)" -L"$(LIBPATH2)"

OBJS=main.o robot_control.o adc.o obstacle.o vl53l0x.o ledControl.o startup.o serial.o newlib_stubs.o lcd.o
main.hex: $(OBJS)
	$(LD) $(OBJS) $(LIBSPEC) -Os -u _printf_float -nostdlib -lnosys -lgcc -T ../Common/LDscripts/stm32l051xx.ld --cref -Map main.map -o main.elf
	arm-none-eabi-objcopy -O ihex main.elf main.hex
	@echo Success!

ledControl.o: ledControl.c ledControl.h
	$(CC) -c $(CCFLAGS) ledControl.c -o ledControl.o

main.o: main.c adc.h ledControl.h
	$(CC) -c $(CCFLAGS) main.c -o main.o

adc.o: adc.c adc.h
	$(CC) -c $(CCFLAGS) adc.c -o adc.o

startup.o: ../Common/Source/startup.c
	$(CC) -c $(CCFLAGS) -DUSE_USART1 ../Common/Source/startup.c -o startup.o

serial.o: ../Common/Source/serial.c
	$(CC) -c $(CCFLAGS) ../Common/Source/serial.c -o serial.o
	
newlib_stubs.o: ../Common/Source/newlib_stubs.c
	$(CC) -c $(CCFLAGS) ../Common/Source/newlib_stubs.c -o newlib_stubs.o

robot_control.o: robot_control.c robot_control.h adc.h ledControl.h
	$(CC) -c $(CCFLAGS) robot_control.c -o robot_control.o

obstacle.o: obstacle.c obstacle.h vl53l0x.h
	$(CC) -c $(CCFLAGS) obstacle.c -o obstacle.o

vl53l0x.o: vl53l0x.c vl53l0x.h
	$(CC) -c $(CCFLAGS) vl53l0x.c -o vl53l0x.o
lcd.o: lcd.c lcd.h
	$(CC) -c $(CCFLAGS) lcd.c -o lcd.o
clean: 
	@del $(OBJS) 2>NUL
	@del main.elf main.hex main.map 2>NUL

Load_Flash: main.hex
	@taskkill /f /im putty.exe /t /fi "status eq running" > NUL
	@echo ..\stm32flash\stm32flash -w main.hex -v -g 0x0 ^^>loadf.bat
	@..\stm32flash\BO230\BO230 -b >>loadf.bat
	@loadf
	@echo cmd /c start putty.exe -sercfg 115200,8,n,1,N -serial ^^>sputty.bat
	@..\stm32flash\BO230\BO230 -r >>sputty.bat
	@sputty
	
putty:
	@taskkill /f /im putty.exe /t /fi "status eq running" > NUL
	@echo cmd /c start putty.exe -sercfg 115200,8,n,1,N -serial ^^>sputty.bat
	@..\stm32flash\BO230\BO230 -r >>sputty.bat
	@sputty
	
explorer:
	@explorer .

dummy: main.map main.hex
	@echo Hello from 'dummy' target...