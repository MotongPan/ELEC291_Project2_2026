#ifndef __LCD_H__
#define __LCD_H__

void LCD_Init(void);
void LCD_Clear(void);
void LCD_SetCursor(unsigned char row, unsigned char col);
void LCD_Print(const char *str);
void LCD_PrintStatusDistance(const char *status, unsigned int dist_mm);

#endif