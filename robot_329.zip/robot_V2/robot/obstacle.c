#include "obstacle.h"
#include "vl53l0x.h"
#include "../Common/Include/stm32l051xx.h"
#include "../Common/Include/serial.h"
#include "ledControl.h"
#include "robot_control.h"

#include "lcd.h"
void wait_us(int us)
{
    while(us--)
    {
        for(int i=0; i<8; i++); 
    }
}
void I2C_init (void)
{
	RCC->IOPENR  |= BIT1;// peripheral clock enable for port B (I2C pins are in port B)
	RCC->APB1ENR  |= BIT21; // peripheral clock enable for I2C1 (page 177 of RM0451 Reference manual)
	
	//Configure PB6 for I2C1_SCL, pin 29 in LQFP32 package (page 44 of datasheet en.DM00108219.pdf)
	GPIOB->MODER = (GPIOB->MODER & ~(BIT12|BIT13)) | BIT13; // PB6 AF-Mode (page 200 of RM0451 Reference manual)
	GPIOB->AFR[0] |= BIT24; // AF1 selected (page 204 of RM0451 Reference manual)
	
	//Configure PB7 for I2C1_SDA, pin 30 in LQFP32 package (page 44 of datasheet en.DM00108219.pdf)
	GPIOB->MODER = (GPIOB->MODER & ~(BIT14|BIT15)) | BIT15; // PB7 AF-Mode (page 200 of RM0451 Reference manual)
	GPIOB->AFR[0] |= BIT28; // AF1 selected  (page 204 of RM0451 Reference manual)
	
	GPIOB->OTYPER   |= BIT6 | BIT7; // I2C pins (PB6 and PB7)  must be open drain
	GPIOB->OSPEEDR  |= BIT12 | BIT14; // Medium speed for PB6 and PB7

	// This configures the I2C clock (Check page 564 of RM0451).  SCLK must be 100kHz or less.
	I2C1->TIMINGR = (uint32_t)0x70420f13;
}

unsigned char i2c_read_addr8_data8(unsigned char address, unsigned char * value)
{
	
	// First we send the address we want to read from:
	I2C1->CR1 = I2C_CR1_PE;
	I2C1->CR2 = I2C_CR2_AUTOEND | (1 << 16) | (0x52);
	I2C1->CR2 |= I2C_CR2_START; // Go
	while ((I2C1->ISR & I2C_ISR_TXE) != I2C_ISR_TXE) {} // Wait for address to go

	I2C1->TXDR = address; // send data
	while ((I2C1->ISR & I2C_ISR_TXE) != I2C_ISR_TXE) {} // Check Tx empty

	delayms(1);
	
	// Second: we gatter the data sent by the slave device
	I2C1->CR1 = I2C_CR1_PE | I2C_CR1_RXIE;
	I2C1->CR2 = I2C_CR2_AUTOEND | (1 << 16) | I2C_CR2_RD_WRN | (0x52); // Read one byte from slave 0x52
	I2C1->CR2 |= I2C_CR2_START; // Go
    
	while ((I2C1->ISR & I2C_ISR_RXNE) != I2C_ISR_RXNE) {} // Wait for data to arrive
	*value=I2C1->RXDR; // Reading 'receive' register clears RXNE flag

	delayms(1);

	return 1;
}

unsigned char i2c_read_addr8_data16(unsigned char address, unsigned short * value)
{
	// First we send the address we want to read from:
	I2C1->CR1 = I2C_CR1_PE;
	I2C1->CR2 = I2C_CR2_AUTOEND | (1 << 16) | (0x52);
	I2C1->CR2 |= I2C_CR2_START; // Go
	while ((I2C1->ISR & I2C_ISR_TXE) != I2C_ISR_TXE) {} // Wait for address to go

	I2C1->TXDR = address; // send data
	while ((I2C1->ISR & I2C_ISR_TXE) != I2C_ISR_TXE) {} // Check Tx empty

	delayms(1);
	
	// Second: we gatter the data sent by the slave device
	I2C1->CR1 = I2C_CR1_PE | I2C_CR1_RXIE;
	I2C1->CR2 = I2C_CR2_AUTOEND | (2<<16) | I2C_CR2_RD_WRN | (0x52); // Read two bytes from slave 0x52
	I2C1->CR2 |= I2C_CR2_START; // Go
    
	while ((I2C1->ISR & I2C_ISR_RXNE) != I2C_ISR_RXNE) {} // Wait for data to arrive
	*value=I2C1->RXDR*256; // Reading 'receive' register clears RXNE flag
   
	while ((I2C1->ISR & I2C_ISR_RXNE) != I2C_ISR_RXNE) {} // Wait for data to arrive
	*value+=I2C1->RXDR; // Reading 'receive' register clears RXNE flag
    
	delayms(1);
	
	return 1;
}

unsigned char i2c_write_addr8_data8(unsigned char address, unsigned char value)
{
	I2C1->CR1 = I2C_CR1_PE;
	I2C1->CR2 = I2C_CR2_AUTOEND | (2 << 16) | (0x52);
	I2C1->CR2 |= I2C_CR2_START;
	while ((I2C1->ISR & I2C_ISR_TXE) != I2C_ISR_TXE) {} // Wait for address to go

	I2C1->TXDR = address; // send register address
	while ((I2C1->ISR & I2C_ISR_TXE) != I2C_ISR_TXE) {} // Check Tx empty

	I2C1->TXDR = value; // send data
	while ((I2C1->ISR & I2C_ISR_TXE) != I2C_ISR_TXE) {} // Check Tx empty

	delayms(1);

	return 1;
}
void Buzzer_Init(void)
{
    RCC->IOPENR |= BIT1; // enable GPIOB clock

    // PB0 as general purpose output
    GPIOB->MODER &= ~(BIT0 | BIT1);
    GPIOB->MODER |= BIT0;

    // push-pull
    GPIOB->OTYPER &= ~BIT0;

    // start with buzzer off
    GPIOB->ODR &= ~BIT0;
}

void Buzzer_Beep(void)
{
    int i;
    //motor_stop_blink();
    for(i=0; i<100; i++) 
    {
        GPIOB->ODR |= BIT0;
        wait_us(244);   

        GPIOB->ODR &= ~BIT0;
        wait_us(244);   
    }
    motor_stop_blink();
    for(i=0; i<100; i++) 
    {
        GPIOB->ODR |= BIT0;
        wait_us(244);   

        GPIOB->ODR &= ~BIT0;
        wait_us(244);   
    }
}

void Buzzer_Off(void)
{
    GPIOB->ODR &= ~BIT0;
}


#define OBSTACLE_THRESHOLD_MM 120

static uint16_t last_distance_mm = 0;
static int sensor_ready = 0;

void Obstacle_Init(void)
{
    unsigned char success;

    I2C_init();
    
    success = vl53l0x_init();

    if(success)
    {
        sensor_ready = 1;
    }
    else
    {
        sensor_ready = 0;
    }
}

uint16_t Obstacle_GetDistanceMM(void)
{
    unsigned char success;
    unsigned short range = 0;

    if(!sensor_ready)
    {
        return 0;
    }

    success = vl53l0x_read_range_single(&range);

    if(success)
    {
        last_distance_mm = (uint16_t)range;
    }

    return last_distance_mm;
}

int Obstacle_IsBlocked(void)
{
    uint16_t distance;

    distance = Obstacle_GetDistanceMM();

    if(distance > 0 && distance < OBSTACLE_THRESHOLD_MM)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int Obstacle_IsReady(void)
{
    return sensor_ready;
}
void Obstacle_LCD_Update(void)
{
    unsigned int dist;
    const char *status;

    dist = Obstacle_GetDistanceMM();

    if(!Obstacle_IsReady())
        status = "TOF FAIL";
    else if(dist > 0 && dist < OBSTACLE_THRESHOLD_MM)
        status = "BLOCKED";
    else
        status = "CLEAR";

    LCD_PrintStatusDistance(status, dist);
}