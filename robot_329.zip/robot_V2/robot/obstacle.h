#ifndef OBSTACLE_H
#define OBSTACLE_H
#include "lcd.h"
#include <stdint.h>
void Buzzer_Init(void);
void Buzzer_Beep(void);
void Buzzer_Off(void);
void I2C_init (void);
void Obstacle_Init(void);
void wait_us(int us);
void Obstacle_LCD_Update(void);
uint16_t Obstacle_GetDistanceMM(void);
int Obstacle_IsBlocked(void);
int Obstacle_IsReady(void);
unsigned char i2c_read_addr8_data8(unsigned char address, unsigned char * value);
unsigned char i2c_read_addr8_data16(unsigned char address, unsigned short * value);
unsigned char i2c_write_addr8_data8(unsigned char address, unsigned char value);

#endif

