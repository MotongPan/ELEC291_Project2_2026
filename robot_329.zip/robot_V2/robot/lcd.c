#include "../Common/Include/stm32l051xx.h"
#include "../Common/Include/serial.h"
#include <stdio.h>
#include "lcd.h"

// ---------------- Pin mapping ----------------
// PB5 -> D7
// PB4 -> D6
// PB3 -> D5
// PA11 -> D4
// PA7 -> E
// PB1 -> RS
// RW -> GND
// ---------------------------------------------


#define LCD_RS_HIGH()   (GPIOB->ODR |= BIT1)
#define LCD_RS_LOW()    (GPIOB->ODR &= ~BIT1)

#define LCD_E_HIGH()    (GPIOA->ODR |= BIT7)
#define LCD_E_LOW()     (GPIOA->ODR &= ~BIT7)

#define LCD_D7_HIGH()   (GPIOB->ODR |= BIT5)
#define LCD_D7_LOW()    (GPIOB->ODR &= ~BIT5)

#define LCD_D6_HIGH()   (GPIOB->ODR |= BIT4)
#define LCD_D6_LOW()    (GPIOB->ODR &= ~BIT4)

#define LCD_D5_HIGH()   (GPIOB->ODR |= BIT3)
#define LCD_D5_LOW()    (GPIOB->ODR &= ~BIT3)

#define LCD_D4_HIGH()   (GPIOA->ODR |= BIT11)
#define LCD_D4_LOW()    (GPIOA->ODR &= ~BIT11)

// ���㹤�������е� delayms()
// ���û�У����Լ����� wait_us / waitms
extern void delayms(int ms);

static void LCD_PulseEnable(void)
{
    LCD_E_HIGH();
    delayms(1);
    LCD_E_LOW();
    delayms(1);
}

static void LCD_Write4Bits(unsigned char nibble)
{
    // bit3 -> D7
    if(nibble & 0x08) LCD_D7_HIGH(); else LCD_D7_LOW();
    // bit2 -> D6
    if(nibble & 0x04) LCD_D6_HIGH(); else LCD_D6_LOW();
    // bit1 -> D5
    if(nibble & 0x02) LCD_D5_HIGH(); else LCD_D5_LOW();
    // bit0 -> D4
    if(nibble & 0x01) LCD_D4_HIGH(); else LCD_D4_LOW();

    LCD_PulseEnable();
}

static void LCD_WriteByte(unsigned char value, unsigned char isData)
{
    if(isData) LCD_RS_HIGH();
    else       LCD_RS_LOW();

    LCD_Write4Bits(value >> 4);      // high nibble
    LCD_Write4Bits(value & 0x0F);    // low nibble

    delayms(2);
}

static void LCD_Command(unsigned char cmd)
{
    LCD_WriteByte(cmd, 0);
}

static void LCD_Data(unsigned char data)
{
    LCD_WriteByte(data, 1);
}

void LCD_Clear(void)
{
    LCD_Command(0x01);
    delayms(2);
}

void LCD_SetCursor(unsigned char row, unsigned char col)
{
    unsigned char addr;

    if(row == 0) addr = 0x00 + col;
    else         addr = 0x40 + col;

    LCD_Command(0x80 | addr);
}

void LCD_Print(const char *str)
{
    while(*str)
    {
        LCD_Data(*str++);
    }
}

void LCD_Init(void)
{
    // Enable GPIOA and GPIOB clocks
    RCC->IOPENR |= BIT0; // GPIOA
    RCC->IOPENR |= BIT1; // GPIOB

    // -------- Configure PA7 as output (E) --------
    GPIOA->MODER &= ~(BIT14 | BIT15); // PA7 mode bits
    GPIOA->MODER |= BIT14;            // output
    GPIOA->OTYPER &= ~BIT7;           // push-pull

    // -------- Configure PA11 as output (D4) --------
    GPIOA->MODER &= ~(BIT22 | BIT23);
    GPIOA->MODER |= BIT22;
    GPIOA->OTYPER &= ~BIT11;

    // -------- Configure PB1 as output (RS) --------
    GPIOB->MODER &= ~(BIT2 | BIT3);
    GPIOB->MODER |= BIT2;
    GPIOB->OTYPER &= ~BIT1;

    // -------- Configure PB3, PB4, PB5 as output (D5,D6,D7) --------
    GPIOB->MODER &= ~(BIT6 | BIT7);   // PB3
    GPIOB->MODER |= BIT6;
    GPIOB->OTYPER &= ~BIT3;

    GPIOB->MODER &= ~(BIT8 | BIT9);   // PB4
    GPIOB->MODER |= BIT8;
    GPIOB->OTYPER &= ~BIT4;

    GPIOB->MODER &= ~(BIT10 | BIT11); // PB5
    GPIOB->MODER |= BIT10;
    GPIOB->OTYPER &= ~BIT5;

    // default low
    LCD_RS_LOW();
    LCD_E_LOW();
    LCD_D7_LOW();
    LCD_D6_LOW();
    LCD_D5_LOW();
    LCD_D4_LOW();

    delayms(30);

    // HD44780 4-bit init sequence
    LCD_RS_LOW();
    LCD_Write4Bits(0x03);
    delayms(10);

    LCD_Write4Bits(0x03);
    delayms(5);

    LCD_Write4Bits(0x03);
    delayms(5);

    LCD_Write4Bits(0x02); // enter 4-bit mode
    delayms(5);

    LCD_Command(0x28); // 4-bit, 2 lines, 5x8
    LCD_Command(0x0C); // display on, cursor off
    LCD_Command(0x06); // entry mode
    LCD_Clear();
}

void LCD_PrintStatusDistance(const char *status, unsigned int dist_mm)
{
    char line[17];

    LCD_Clear();

    LCD_SetCursor(0, 0);
    snprintf(line, sizeof(line), "ST:%-13s", status);
    LCD_Print(line);

    LCD_SetCursor(1, 0);
    snprintf(line, sizeof(line), "D:%4umm        ", dist_mm);
    LCD_Print(line);
}