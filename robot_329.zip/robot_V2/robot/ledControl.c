#include "../Common/Include/stm32l051xx.h"
#include "ledControl.h"
#include "robot_control.h"
volatile int x;

static void delay(int dly)
{
    while(dly--) x++;
}

void LED_Init(void)
{
    RCC->IOPENR |= BIT0; 
    GPIOA->MODER = (GPIOA->MODER & ~(BIT13 | BIT12)) | BIT12;
    GPIOA->MODER = (GPIOA->MODER & ~(BIT27 | BIT26)) | BIT26;
    
    GPIOA->ODR &= ~(BIT6 | BIT13);
}

void Turn_Right_Flash(int n)
{
	int i;   
	for(i = 0; i < n; i++)
	{
    	GPIOA->ODR &= ~BIT13;
    	GPIOA->ODR |= BIT6;
    	delay(300000);
    	GPIOA->ODR &= ~BIT6;
    	delay(300000);
    }
}

void Turn_Left_Flash(int n)
{
	int i;   
	for(i = 0; i < n; i++)
	{
    GPIOA->ODR &= ~BIT6;
    GPIOA->ODR |= BIT13;
    delay(300000);
    GPIOA->ODR &= ~BIT13;
    delay(300000);
    }
}

void Hazard_Lights(int n)
{
    int i;   
	for(i = 0; i < n; i++)
	{
    GPIOA->ODR |= (BIT6 | BIT13);
    delay(400000);
    GPIOA->ODR &= ~(BIT6 | BIT13);
    delay(400000);
    }
}