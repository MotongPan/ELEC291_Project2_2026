#include "../Common/Include/stm32l051xx.h"

#define BIT0  (1U << 0)
#define BIT12 (1U << 12)
#define BIT13 (1U << 13)
#define BIT14 (1U << 14)
#define BIT15 (1U << 15)
#define BIT24 (1U << 24)
#define BIT25 (1U << 25)
#define BIT26 (1U << 26)
#define BIT27 (1U << 27)
#define BIT28 (1U << 28)
#define BIT29 (1U << 29)
#define BIT30 (1U << 30)
#define BIT31 (1U << 31)

int main(void)
{
    // Enable GPIOA clock
    RCC->IOPENR |= BIT0;

    // PA12 output
    GPIOA->MODER = (GPIOA->MODER & ~(BIT24 | BIT25)) | BIT24;
    GPIOA->OTYPER &= ~BIT12;

    // PA13 output
    GPIOA->MODER = (GPIOA->MODER & ~(BIT26 | BIT27)) | BIT26;
    GPIOA->OTYPER &= ~BIT13;

    // PA14 output
    GPIOA->MODER = (GPIOA->MODER & ~(BIT28 | BIT29)) | BIT28;
    GPIOA->OTYPER &= ~BIT14;

    // PA15 output
    GPIOA->MODER = (GPIOA->MODER & ~(BIT30 | BIT31)) | BIT30;
    GPIOA->OTYPER &= ~BIT15;

    // Default: all low
    GPIOA->ODR &= ~(BIT12 | BIT13 | BIT14 | BIT15);

    // Only PA12 high
    GPIOA->ODR |= BIT12;

    while (1)
    {
    }
}