#define BUTT0 (1<<PD2)// stop
#define BUTT1 (1<<PC3)// mode
#define BUTT2 (1<<PC2)// page
#define BUTT3 (1<<PC1)// 180/forward
#define BUTT4 (1<<PC0)// p1/back
#define BUTT5 (1<<PB2)// p2/left
#define BUTT6 (1<<PB1)// p3/right

void stop_car(void);
void toggle_mode(void);
void swap_page(void);
void forward_and_pi_rad(void);
void back_and_p1(void);
void left_and_p2(void);
void right_and_p3(void);
void Configure_Pins(void);
void check_press(void);
void check_joystick(void);
void ADC_Init(void);

uint16_t ADC_Read(int pin);
unsigned char last_cmd;