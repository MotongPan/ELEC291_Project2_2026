#include "lcd.h"
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "usart.h"
#include "pushbutton.h"
#include "SoftwareUart.h"

// Auto command signals (paths)
// Send 8 bits for convenience. Example function takes unsigned char input
unsigned char autoP1=0b11110000;
unsigned char autoP2=0b11111110;
unsigned char autoP3=0b11111100;
unsigned char toggle_auto=0b11111000;
// Manual Command signals
unsigned char stop=0b01010101;
unsigned char forward=0b00000001;
unsigned char backward=0b00000010;
unsigned char left=0b00000011;
unsigned char right=0b00000100;
unsigned char one80=0b00000101;


unsigned int mode = 0;
unsigned int page = 0;
unsigned int LCD_update_request = 0;

/* Pinout for DIP28 ATMega328P:

                           -------
     (PCINT14/RESET) PC6 -|1    28|- PC5 (ADC5/SCL/PCINT13)
       (PCINT16/RXD) PD0 -|2    27|- PC4 (ADC4/SDA/PCINT12)
       (PCINT17/TXD) PD1 -|3    26|- PC3 (ADC3/PCINT11)
      (PCINT18/INT0) PD2 -|4    25|- PC2 (ADC2/PCINT10)
 (PCINT19/OC2B/INT1) PD3 -|5    24|- PC1 (ADC1/PCINT9)
    (PCINT20/XCK/T0) PD4 -|6    23|- PC0 (ADC0/PCINT8)
                     VCC -|7    22|- GND
                     GND -|8    21|- AREF
(PCINT6/XTAL1/TOSC1) PB6 -|9    20|- AVCC
(PCINT7/XTAL2/TOSC2) PB7 -|10   19|- PB5 (SCK/PCINT5)
   (PCINT21/OC0B/T1) PD5 -|11   18|- PB4 (MISO/PCINT4)
 (PCINT22/OC0A/AIN0) PD6 -|12   17|- PB3 (MOSI/OC2A/PCINT3)
      (PCINT23/AIN1) PD7 -|13   16|- PB2 (SS/OC1B/PCINT2)
  (PCINT0/CLKO/ICP1) PB0 -|14   15|- PB1 (OC1A/PCINT1)
                           -------
*/

void check_press(void)
{
	if (!(PIND &BUTT0)) stop_car();
	if(((~PINC)&0b00000111) || ((~PINB)&0b00000110))
	{
		toggle_mode();
		swap_page();
		forward_and_pi_rad();
		back_and_p1();
	}
	if((~PINB) &0b00000110){
		left_and_p2();
		right_and_p3();
	}
}

void check_joystick (void) {
	uint16_t x_val = ADC_Read(5); // vrx on adc 5
	uint16_t y_val = ADC_Read(4); // vry on acd 4
	
	unsigned char curr_cmd;
	
	int low_end = 400; 
	int high_end = 620;
	
	if (y_val > high_end) {
		curr_cmd = 'F';
	} else if (y_val < low_end) {
		curr_cmd = 'B';
	} else {
		if (x_val > high_end) {
			curr_cmd = 'R';
		} else if (x_val < low_end) {
			curr_cmd = 'L';
		} else {
			curr_cmd = 'S';
		}
	}
	
	if (curr_cmd != last_cmd) {
		SendByte(curr_cmd);
		last_cmd = curr_cmd;
	}
}

void stop_car(void)
{
	if(!(PIND&BUTT0))
	{
		_delay_ms(20);		//Debounce Press
		if(!(PIND&BUTT0))
		{
			SendByte('S');
			//LCDprint("Stop", 1, 1);
			while(!(PIND&BUTT0));
			_delay_ms(20); 	// Debounce Release
		}
	}
}

void toggle_mode(void)
{
	if(!(PINC&BUTT1))
	{
		_delay_ms(20);		//Debounce Press
		if(!(PINC&BUTT1))
		{
			mode^=1;
			SendByte('M');
			//LCD_update_request = 1; // Request to update LCD with auto/manual message
			while(!(PINC&BUTT1));
			_delay_ms(20); 	// Debounce Release
		}
	}
}

void swap_page(void)
{
	if(!(PINC&BUTT2))
	{
		_delay_ms(20);		//Debounce Press
		if(!(PINC&BUTT2))
		{
			page^=1;
			//LCD_update_request = 1; // Request to update LCD with new button functions
			while(!(PINC&BUTT2));
			_delay_ms(20); 	// Debounce Release
		}
	}
}

void forward_and_pi_rad(void) //pi rad sounds cooler than one_eighty
{
	if(!(PINC&BUTT3))
	{
		_delay_ms(20);		//Debounce Press
		if(!(PINC&BUTT3))
		{
			if(page)
			{
				//LCDprint("Forward", 1, 1);
				SendByte('F');
			}
			else
			{
				SendByte('O');
				//LCDprint("One Eighty", 1, 1);
			}
			while(!(PINC&BUTT3));
			_delay_ms(20); 	// Debounce Release
		}
	}
}

void back_and_p1(void)
{
	if(!(PINC&BUTT4))
	{
		_delay_ms(20);		//Debounce Press
		if(!(PINC&BUTT4))
		{
			if(page)
			{
				SendByte('B');
				//LCDprint("Backward", 1, 1);
			}
			else
			{
				SendByte('1');
				//LCDprint("Path One", 1, 1);
			}
			while(!(PINC&BUTT4));
			_delay_ms(20); 	// Debounce Release
		}
	}
}

void left_and_p2(void)
{
	if(!(PINB&BUTT5))
	{
		_delay_ms(20);		//Debounce Press
		if(!(PINB&BUTT5))
		{
			if(page)
			{
				SendByte('L');
				//LCDprint("Left", 1, 1);
			}
			else
			{
				SendByte('2');
				//LCDprint("Path Two", 1, 1);
			}
			while(!(PINB&BUTT5));
			_delay_ms(20); 	// Debounce Release
		}
	}
}

void right_and_p3(void)
{
	if(!(PINB&BUTT6))
	{
		_delay_ms(20);		//Debounce Press
		if(!(PINB&BUTT6))
		{
			if(page)
			{
				SendByte('R');
				//LCDprint("Right", 1, 1);
			}
			else
			{
				SendByte('3');
				//LCDprint("Path Three", 1, 1);
			}
			while(!(PINB&BUTT6));
			_delay_ms(20); 	// Debounce Release
		}
	}
}

void ADC_Init(void)
{
    ADMUX = (1<<REFS0);
    ADCSRA = (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);
}

uint16_t ADC_Read(int pin)
{
    pin &= 0x7;
    ADMUX = (ADMUX & 0xF8)|pin;
     
    ADCSRA |= (1<<ADSC);
     
    while(ADCSRA & (1<<ADSC)); //as long as ADSC pin is 1 just wait.
     
    return (ADCW);
}

/*void update_lcd(void)
{
	if(LCD_update_request)
	{
		LCD_update_request = 0;
		if(page)
		{
			LCDprint("STP FOR BCK L R", 2, 1);
		}
		else
		{
			LCDprint("STP 180 P1 P2 P3", 2, 1);
		}
		if(mode)
		{
			LCDprint("Field Following", 1, 1);
		}
		else
		{
			LCDprint("Manual Driving", 1, 1);
		}
	}
}*/

void Configure_Pins(void)
{
	DDRB|=0b00000001; // PB0 is output.
	//DDRD|=0b11111100; // PD2, PD4, PD5, PD6, and PD7 are outputs.
	
	DDRD |= (1 << PD3);
	DDRD &= ~(1 << PD2);
	PORTD |= (1 << PD2);
	
//	DDRD &= ~(1 << PD2); // the random button lol
//	PORTD |= (1 << PD2);
	
	// joystick
	//DDRC &= ~((1 << PC4) | (1 << PC5)); // PC4, PC5 inputs
	
	//PORTC &= ~((1 << PC4) | (1 << PC5)); // disable pullup resistors for PC4, PC5

	ADC_Init();
	
	DDRC  &= 0b11000000; // Buttons 0-4
	PORTC |= 0b00001111; // Activate pull-up in PC0-4
	PORTC &= 0b11001111;
	DDRB  &= 0b11111001; // Buttons 5-6
	PORTB |= 0b00000110; // Activate pull-up in PB1-2
}
