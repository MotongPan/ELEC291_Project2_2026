#define BUTT0 (1<<4)
#define BUTT1 (1<<3)
#define BUTT2 (1<<2)
#define BUTT3 (1<<1)
#define BUTT4 (1<<0)
#define BUTT5 (1<<2)
#define BUTT6 (1<<1)

void stop_car(void);
void toggle_mode(void);
void swap_page(void);
void forward_and_pi_rad(void);
void back_and_p1(void);
void left_and_p2(void);
void right_and_p3(void);
void Configure_Pins(void);
void check_press(void);