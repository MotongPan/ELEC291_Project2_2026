#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include "usart.h"
#include "lcd.h"
#include "SoftwareUart.h"
#include "pushbutton.h"
#include <util/delay.h>

#define AUTO 1
#define MANU 0

/* Pinout for DIP28 ATMega328P:

                           -------
     (PCINT14/RESET) PC6 -|1    28|- PC5 (ADC5/SCL/PCINT13)
       (PCINT16/RXD) PD0 -|2    27|- PC4 (ADC4/SDA/PCINT12)
       (PCINT17/TXD) PD1 -|3    26|- PC3 (ADC3/PCINT11)
      (PCINT18/INT0) PD2 -|4    25|- PC2 (ADC2/PCINT10)
 (PCINT19/OC2B/INT1) PD3 -|5    24|- PC1 (ADC1/PCINT9)
    (PCINT20/XCK/T0) PD4 -|6    23|- PC0 (ADC0/PCINT8)
                     VCC -|7    22|- GND
                     GND -|8    21|- AREF
(PCINT6/XTAL1/TOSC1) PB6 -|9    20|- AVCC
(PCINT7/XTAL2/TOSC2) PB7 -|10   19|- PB5 (SCK/PCINT5)
   (PCINT21/OC0B/T1) PD5 -|11   18|- PB4 (MISO/PCINT4)
 (PCINT22/OC0A/AIN0) PD6 -|12   17|- PB3 (MOSI/OC2A/PCINT3)
      (PCINT23/AIN1) PD7 -|13   16|- PB2 (SS/OC1B/PCINT2)
  (PCINT0/CLKO/ICP1) PB0 -|14   15|- PB1 (OC1A/PCINT1)
                           -------
*/

// These are the connections between the LCD and the ATMega328P:
//
// LCD          ATMega328P
//----------------------------
// D7           PB0
// D6           PD7
// D5           PD6
// D4           PD5
// LCD_E        PD4
// LCD_W        GND
// LCD_RS       PD3
// V0           2k+GND
// VCC          5V
// GND          GND
//
// There is also a picture that shows how the LCD is attached to the ATMega328P.

int main( void )
{
	usart_init(); // configure the usart and baudrate
	
	Configure_Pins();
	LCD_4BIT();
	IR_Init();
	IR_On();
	
	_delay_ms(500); // Give putty some time to start.
	printf("ATMega328P 4-bit LCD test.\n");

   	// Display something in the LCD
	LCDprint("Intro", 1, 1);
	LCDprint("STP 180 P1 P2 P3", 2, 1);
	while(1)
	{
		check_press();
		update_lcd();
	}
}
