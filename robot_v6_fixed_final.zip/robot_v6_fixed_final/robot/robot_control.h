#ifndef __ROBOT_CONTROL_H__
#define __ROBOT_CONTROL_H__
#include "../Common/Include/stm32l051xx.h"
#define F_CPU 32000000L
#define PWM_PERIOD_COUNT 100

void handle_instr(uint8_t instr);

typedef enum
{
    Auto_mode = 0,
    Manual_mode,
    Follow_mode
} RobotMode;

typedef enum
{
    Go_forward = 0,
    Go_left,
    Go_right,
    End_stop
} PathAction;

extern unsigned char path_number;
extern RobotMode current_mode;

extern volatile unsigned char pwm_left;
extern volatile unsigned char pwm_right;
extern volatile unsigned char pwm_counter;

void PWM_Hardware_Init(void);
void TIM2_Handler(void);

void follow_mode_task(void);

void Turn_Left(void);
void Turn_Right(void);
void Lights_Off(void);
void Hazard_On(void);
void Hazard_off(void);
void motor_stop_blink(void);
void motor_stop(void);
void motor_forward(unsigned char speed);
void motor_backward(unsigned char speed);
void motor_slight_change(unsigned char left_speed, unsigned char right_speed);
void motor_rotate_left(unsigned char speed);
void motor_rotate_right(unsigned char speed);
void auto_mode_task(unsigned char path_number,unsigned char *intersection_count);
void manual_command_execute(unsigned char cmd);

void motor_correct_left(unsigned char speed);
void motor_correct_right(unsigned char speed);
void align_after_intersection(void);


PathAction get_path_action(unsigned char path_number, unsigned char intersection_count);
void execute_path_action(PathAction action);
void move_forward_with_field_detection(void);
void delayms(int len);
unsigned char intersection_detected (void);
#endif