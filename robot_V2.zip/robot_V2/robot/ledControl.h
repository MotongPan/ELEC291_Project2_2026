#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void Turn_Left_Flash(int);
void Turn_Right_Flash(int);
void Hazard_Lights(int);

#endif