#include "robot_control.h"
#include "adc.h"
#include "obstacle.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ledControl.h"
#define MOTOR_STOP 0
#define MOTOR_FORWARD 1
#define MOTOR_BACKWARD 2
#define HBRI_L1_HIGH()   (GPIOA->ODR |= BIT14)
#define HBRI_L1_LOW()    (GPIOA->ODR &= ~BIT14)

#define HBRI_L2_HIGH()   (GPIOA->ODR |= BIT5)
#define HBRI_L2_LOW()    (GPIOA->ODR &= ~BIT5)

#define HBRI_R1_HIGH()   (GPIOA->ODR |= BIT12)
#define HBRI_R1_LOW()    (GPIOA->ODR &= ~BIT12)

#define HBRI_R2_HIGH()   (GPIOA->ODR |= BIT8)
#define HBRI_R2_LOW()    (GPIOA->ODR &= ~BIT8)
#define LED_LEFT_BIT   BIT8  // PA2
#define LED_RIGHT_BIT  BIT3   // PA3
#define INTERSECTION_THRESHOLD  1200
#define MAIN_LOOP_DELAY_MS          50
#define INTERSECTION_COOLDOWN_MS    77000
#define INTERSECTION_COOLDOWN_TICKS (INTERSECTION_COOLDOWN_MS / MAIN_LOOP_DELAY_MS)

#define baud 3000 // baud rate of ir

//(2/3.3)*4095
volatile unsigned char pwm_left = 0;
volatile unsigned char pwm_right = 0;
volatile unsigned char pwm_counter = 0;
volatile unsigned char left_dir = MOTOR_STOP;
volatile unsigned char right_dir = MOTOR_STOP;
//volatile  unsigned int cooldown_ticks;
// 3 path 8 intersection 
static const PathAction path_table[3][8] =
{ //path 1,2,3
    { Go_forward, Go_left,    Go_left,    Go_forward, Go_right,   Go_left,    Go_right,   End_stop },
    { Go_left,    Go_right,   Go_left,    Go_right,   Go_forward, Go_forward, End_stop,   End_stop },
    { Go_right,   Go_forward, Go_right,   Go_left,    Go_right,   Go_left,    Go_forward, End_stop }
};
PathAction get_path_action(unsigned char path_number, unsigned char intersection_count)
{ //path table start from 0 (not1)
    /*if (path_number < 1 || path_number > 3 || intersection_count < 1 || intersection_count > 8)
        return End_stop;*/
   return path_table[path_number - 1][intersection_count - 1];
}


typedef enum {
	STEER_NONE = 0,
    STEER_LEFT,
    STEER_RIGHT
} SteerDir;

static SteerDir last_steer = STEER_NONE;

void PWM_Hardware_Init(void)
{
	// Set up output pins
	RCC->IOPENR |= BIT0; // peripheral clock enable for port A
   
    GPIOA->MODER = (GPIOA->MODER & ~(BIT28 | BIT29)) | BIT28;
    GPIOA->OTYPER &= ~BIT14;
    
    GPIOA->MODER = (GPIOA->MODER & ~(BIT10 | BIT11)) | BIT10;
    GPIOA->OTYPER &= ~BIT5;
    
    GPIOA->MODER = (GPIOA->MODER & ~(BIT24 | BIT25)) | BIT24;
    GPIOA->OTYPER &= ~BIT12;
    
    GPIOA->MODER = (GPIOA->MODER & ~(BIT16 | BIT17)) | BIT16;
    GPIOA->OTYPER &= ~BIT8;
    
    RCC->APB1ENR |= BIT17; // usart2 clock
    
    // PA3 for alternate fx 4 (usart2 rx)
    GPIOA->MODER = (GPIOA->MODER &~(BIT6 | BIT7)) | BIT7;
    GPIOA->AFR[0] = (GPIOA->AFR[0] &~0xF000) | 0x4000;
    
    USART2->BRR = F_CPU / baud;
    
    USART2->CR1 = BIT0 | BIT2 | BIT5;
    
    // PA2->potentiometer input
    GPIOA->MODER |= (BIT4 | BIT5);
    
	// Set up timer
    GPIOA->ODR &= ~(BIT8 | BIT11 | BIT12 | BIT13 | BIT14 | BIT15);//push down other pins
	RCC->APB1ENR |= BIT0;  // turn on clock for timer2 (UM: page 177)
	TIM2->ARR = F_CPU / 100000L - 1;
	NVIC->ISER[0] |= BIT15; // enable timer 2 interrupts in the NVIC
	TIM2->CR1 |= BIT4;      // Downcounting    
	TIM2->CR1 |= BIT7;      // ARPE enable    
	TIM2->DIER |= BIT0;     // enable update event (reload event) interrupt 
	TIM2->CR1 |= BIT0;      // enable counting    
	
	NVIC->ISER[0] |= (1UL << 28); // usart is IRQ 28
	
	__enable_irq();
}

void TIM2_Handler(void)
{
    TIM2->SR &= ~BIT0; // clear update interrupt flag

    pwm_counter++;
    if (pwm_counter >= PWM_PERIOD_COUNT)
    {
        pwm_counter = 0;
    }
    //Left motor
    if (left_dir == MOTOR_FORWARD)
    {
        if (pwm_counter < pwm_left)
            HBRI_L1_HIGH();
        else
            HBRI_L1_LOW();
        HBRI_L2_LOW();
    }
    else if (left_dir == MOTOR_BACKWARD)
    {
        HBRI_L1_LOW();

        if (pwm_counter < pwm_left)
            HBRI_L2_HIGH();
        else
            HBRI_L2_LOW();
    }
    else
    {
        HBRI_L1_LOW();
        HBRI_L2_LOW();
    }

    //Right motor
    if (right_dir == MOTOR_FORWARD)
    {
        if (pwm_counter < pwm_right)
            HBRI_R1_HIGH();
        else
            HBRI_R1_LOW();
        HBRI_R2_LOW();
    }
    else if (right_dir == MOTOR_BACKWARD)
    {
        HBRI_R1_LOW();

        if (pwm_counter < pwm_right)
            HBRI_R2_HIGH();
        else
            HBRI_R2_LOW();
    }
    else
    {
        HBRI_R1_LOW();
        HBRI_R2_LOW();
    }
}

void USART2_Handler(void) {

	if (USART2->ISR & (BIT3 | BIT1 | BIT0)) {
		USART2->ICR |= (BIT3 | BIT1 | BIT0);
	}
	
	if (USART2->ISR & BIT5) {
		uint8_t data = (uint8_t)USART2->RDR;
		
		handle_instr(data);
	}
}	


void Turn_Left(void)
{
    GPIOA->ODR |= LED_LEFT_BIT;
    GPIOA->ODR &= ~LED_RIGHT_BIT;
}

void Turn_Right(void)
{
    GPIOA->ODR |= LED_RIGHT_BIT;
    GPIOA->ODR &= ~LED_LEFT_BIT;
}

void Lights_Off(void)
{
    GPIOA->ODR &= ~(LED_LEFT_BIT | LED_RIGHT_BIT);
}
void Hazard_On(void)
{
    GPIOA->ODR |= (LED_LEFT_BIT | LED_RIGHT_BIT);
}

void Hazard_Off(void)
{
    GPIOA->ODR &= ~(LED_LEFT_BIT | LED_RIGHT_BIT);
}
void motor_stop_blink(void)
{
    left_dir = MOTOR_STOP;
    right_dir = MOTOR_STOP;

    pwm_left = 0;
    pwm_right = 0;
    HBRI_L1_LOW();
    HBRI_L2_LOW();
    HBRI_R1_LOW();
    HBRI_R2_LOW();
    Hazard_Lights(3);
}
void motor_stop(void)
{
    left_dir = MOTOR_STOP;
    right_dir = MOTOR_STOP;

    pwm_left = 0;
    pwm_right = 0;

    HBRI_L1_LOW();
    HBRI_L2_LOW();
    HBRI_R1_LOW();
    HBRI_R2_LOW();
}

void motor_forward(unsigned char speed)
{
    left_dir = MOTOR_FORWARD;
    right_dir = MOTOR_FORWARD;

    pwm_left = speed;
    pwm_right = speed;
}

void motor_backward(unsigned char speed)
{
    left_dir = MOTOR_BACKWARD;
    right_dir = MOTOR_BACKWARD;

    pwm_left = speed;
    pwm_right = speed;
}

void motor_rotate_left(unsigned char speed)
{
    left_dir = MOTOR_BACKWARD;
    right_dir = MOTOR_FORWARD;

    pwm_left = speed;
    pwm_right = speed;
    Turn_Left_Flash(2);
}

void motor_rotate_right(unsigned char speed)
{
    left_dir = MOTOR_FORWARD;
    right_dir = MOTOR_BACKWARD;

    pwm_left = speed;
    pwm_right = speed;
    Turn_Right_Flash(2);
}

void motor_slight_change(unsigned char left_speed, unsigned char right_speed)
{
    left_dir = MOTOR_FORWARD;
    right_dir = MOTOR_FORWARD;

    pwm_left = left_speed;
    pwm_right = right_speed;
}

void execute_path_action(PathAction action)
{
	printf("execute start\r\n");
    switch (action)
    {
        case Go_forward:
        	printf("execute Forward\r\n");
        	motor_stop();
        	delayms(300);
            motor_forward(20); //speed not sure
            delayms(3000);
            motor_stop();
        	delayms(300);
            break;

        case Go_left:
        	
        	printf("execute Left\r\n");
       		motor_stop();
        	delayms(300);
            motor_rotate_left(35);
            delayms(300);
            motor_forward(20);
            delayms(400);
            motor_stop();
        	delayms(300);
            break;

        case Go_right:
        	
        	printf("execute right\r\n");
        	motor_stop();
        	delayms(300);
            motor_rotate_right(35);
            delayms(500);
            motor_forward(20);
            delayms(400);
            motor_stop();
        	delayms(300);
            break;

        case End_stop:
        	motor_stop();
        	delayms(2000);
        default:
            motor_stop();
            Lights_Off();
            break;
    }
    printf("execute end\r\n");
}

void move_forward_with_field_detection(void)
{
    unsigned int left_val, right_val;
    int error;

    left_val = adc_read_left();
    right_val = adc_read_right();
    error = (int)left_val - (int)right_val;
    if (left_val > 1500 && right_val > 1500)
    {
		if (error > 300)
        {
            motor_slight_change(10, 18);
            last_steer = STEER_LEFT;
        }
        else if (error < -200)
        {
            motor_slight_change(18, 10);
            last_steer = STEER_RIGHT;
        }
        else
        {
            motor_forward(15);
        }
        
    }
    else// if (left_val < 1500 || right_val < 1500 && left_val > 8 && right_val > 8)aaaa
    {
        if (left_val > right_val)
        {
            motor_slight_change(10, 20);
            last_steer = STEER_LEFT;
        }
        else if (right_val > left_val)
        {
            motor_slight_change(20, 10);
            last_steer = STEER_RIGHT;
        }
        else
        {
            motor_forward(15);
        }
    } 
    /*else {
    	if (last_steer == STEER_LEFT) 
    	{
	    	motor_slight_change(20,10);
	    	delayms(1000);	 
	    }
    	else if(last_steer == STEER_RIGHT) 
    	{
	    	motor_slight_change(10,20);
	    	delayms(1000); 
	    }
    	else motor_forward(15);
    }*/
}
unsigned char intersection_detected(void)
{
    unsigned int inter_val;
    inter_val = adc_read_intersection();

    if (inter_val > INTERSECTION_THRESHOLD)
        return 1;
    else
        return 0;
}

void auto_mode_task(unsigned char path_number, unsigned char *intersection_count)
{
    static unsigned int cooldown_ticks = 0;
    printf("Cool=%u \r\n", cooldown_ticks);
    fflush(stdout);
	if(Obstacle_IsBlocked())
    {
    	motor_stop();
    	
    	return;
    }
    if (cooldown_ticks > 0)
    {
        cooldown_ticks--;
        move_forward_with_field_detection();
        return;
    }
	
    if (intersection_detected())
    {
        (*intersection_count)++;
        execute_path_action(get_path_action(path_number, *intersection_count));
        cooldown_ticks = INTERSECTION_COOLDOWN_TICKS;
    }
    else
    {
        move_forward_with_field_detection();
    }
}
void follow_mode_task(void)
{
    uint16_t d;

    d = Obstacle_GetDistanceMM();
	printf("Follow D=%u\r\n",d);
    if (!Obstacle_IsReady())
    {
        motor_stop();
        return;
    }

    if (d == 0 || d > 500)
    {
        motor_stop();
    }
    else if (d < 20)
    {
        motor_stop();
    }
    else if (d >= 20 && d < 150)
    {
        motor_backward(20);
    }
    else if (d >= 150 && d <= 350)
    {
        motor_forward(20);
    }
    else
    {
        motor_stop();
    }
}

uint8_t get_resistance() {
	uint8_t pot_volt = readADC(ADC_CHSELR_CHSEL2);
	uint8_t r = (100*pot_volt)/(4097-pot_volt);
	return r;
}


void handle_instr(uint8_t instr)
{
	uint8_t resist = get_resistance();
    if(Obstacle_IsBlocked())
    {
    	motor_stop();
    	return;
    }
if (current_mode = Manual_mode) {
    switch(instr)
    {
        case 'F':
            motor_forward(100 / resist);
            break;
        case 'B':
            motor_backward(100 / resist);
            break;
        case 'L':
            motor_rotate_left(100 / resist);
            break;
        case 'R':
            motor_rotate_right(100 / resist);
            break;
        case 'S':
        	motor_stop();
        	break;
        case '1':
        	path_number = 1;
        	break;
        case '2':
        	path_number = 2;
        	break;
        case '3':
        	path_number = 3;
        	break;
        case 'M':
        	current_mode = Auto_mode;
        	break;
        case 'O':
        	motor_rotate_right(100 / resist);
        	break;
        default:
            motor_stop();
            break;
    }
} else if (current_mode = Auto_mode) {
	switch (instr) {
		case 'M':
			motor_stop();
        	current_mode = Follow_mode;
        	break;
        default:
        	break;
    }
} else {
	switch (instr) {
		case 'M':
			motor_stop();
        	current_mode = Manual_mode;
        	break;
        default:
        	break;
	}
}
}